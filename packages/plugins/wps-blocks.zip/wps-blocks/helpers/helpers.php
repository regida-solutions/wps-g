<?php
/**
 * Generate classnames
 *
 * @package WpsBlocks
 **/

declare( strict_types=1 );
namespace WPS\Blocks\Helpers;

require_once __DIR__ . './classnames.php';
