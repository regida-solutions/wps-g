/**
 * WordPress dependencies
 */
import { InnerBlocks } from '@wordpress/block-editor';

function Save() {
	return <InnerBlocks.Content />;
}

export default Save;
